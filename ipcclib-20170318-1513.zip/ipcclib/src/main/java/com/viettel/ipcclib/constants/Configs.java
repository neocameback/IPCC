package com.viettel.ipcclib.constants;

/**
 * Created by Macbook on 3/16/17.
 */

public class Configs {
  public static  final String ROOM_URL ="wss://192.168.0.117:8898";
  public static final String DOMAIN_TEST = "LANT_TEST1";
//  public static final String DOMAIN_TEST = "HOANGNT_TEST3";
}
